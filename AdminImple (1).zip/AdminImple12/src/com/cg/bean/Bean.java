package com.cg.bean;

public class Bean {
	private String name;
	private String addressDetails;
	private String mobileNo;
	private String eMail;
	private int openingBalance;
	private String panCard;
	private int accountId;
	private String accountType;
	
	
	public Bean() {
		super();
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddressDetails() {
		return addressDetails;
	}


	public void setAddressDetails(String addressDetails) {
		this.addressDetails = addressDetails;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String geteMail() {
		return eMail;
	}


	public void seteMail(String eMail) {
		this.eMail = eMail;
	}


	public int getOpeningBalance() {
		return openingBalance;
	}


	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}


	public String getPanCard() {
		return panCard;
	}


	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}


	public int getAccountId() {
		return accountId;
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	@Override
	public String toString() {
		return "Bean [name=" + name + ", addressDetails=" + addressDetails + ", mobileNo=" + mobileNo + ", eMail="
				+ eMail + ", openingBalance=" + openingBalance + ", panCard=" + panCard + ", accountId=" + accountId
				+ ", accountType=" + accountType + "]";
	}


	


	public Bean(String name, String addressDetails, String mobileNo, String eMail, int openingBalance, String panCard,
			String accountType) {
		super();
		this.name = name;
		this.addressDetails = addressDetails;
		this.mobileNo = mobileNo;
		this.eMail = eMail;
		this.openingBalance = openingBalance;
		this.panCard = panCard;
		this.accountType = accountType;
	}


	public Bean(String name, String addressDetails, String mobileNo, String eMail, int openingBalance, String panCard,
			int accountId, String accountType) {
		super();
		this.name = name;
		this.addressDetails = addressDetails;
		this.mobileNo = mobileNo;
		this.eMail = eMail;
		this.openingBalance = openingBalance;
		this.panCard = panCard;
		this.accountId = accountId;
		this.accountType = accountType;
	}


	
	
	
}
