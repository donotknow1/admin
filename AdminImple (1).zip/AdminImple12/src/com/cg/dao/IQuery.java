package com.cg.dao;

public interface IQuery {

	String insert_qry = "insert into customer values(?,?,?,?,?,?,seq.nextval,?)";
	String retrieve_month = "SELECT * FROM transactions WHERE to_char(dateoftransaction,'MM') = ?";
	String retrieve_day ="SELECT * FROM transactions WHERE to_char(dateoftransaction,'DD') = ?";
	String retrieve_year ="SELECT * FROM transactions WHERE to_char(dateoftransaction,'YYYY') = ?";
	String retrieveall = "SELECT * FROM transactions ";

}
