package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.Bean;
import com.cg.dao.Idao;
import com.cg.dao.Idaoimpl;

public class Serviceimpl implements Iservice {
     static Idao d=null;
	@Override
	public int addinfo(Bean b) {
		d=new Idaoimpl();
		return d.addinfo(b);
	}
	@Override
	public boolean validatename(String name) {
		 Pattern pattern=Pattern.compile("[A-Z][a-z]{2,15}");
		   Matcher matcher=pattern.matcher(name);
		   if(matcher.matches()) {
		  // log.info("Name Matches"+name);
		    return true;
		   }
		   else
		   {
		   // log.info("Name is not matching");
		    return false;
		   }
		
	}
	@Override
	public boolean validatemobileNo(String mobileNo) {

		   Pattern pattern=Pattern.compile("{1}[6-9][0-9]{9}");
		   Matcher matcher=pattern.matcher( mobileNo);
		   if(matcher.matches()) {
		  // log.info("mobile number Matches"+ mobileNumber);
		    return true;
		   }
		   else
		   {
		  //  log.info("moblie number is not matching");
		    return false;
		   }
		
	}
	@Override
	public boolean validateeMail(String eMail) {
		 Pattern pattern=Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Za-z]{2,64} ");
		   Matcher matcher=pattern.matcher( eMail);
		   if(matcher.matches()) {
		  // log.info("email Matches"+ eMail);
		    return true;
		   }
		   else
		   {
		    //log.info("email is not matching");
		    return false;
		   }
		
	}
	@Override
	public boolean validateopeningBalance(int openingBalance) {
		if(openingBalance==1000) {
		    openingBalance=1000;
		    return true;
		   }
		   else {
		    System.out.println("please enter valid amount");
		   
		   return false;
		  }
	}
	@Override
	public boolean validatepanCard(String panCard) {
		Pattern pattern=Pattern.compile("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$");
		   Matcher matcher=pattern.matcher( panCard);
		   if(matcher.matches()) {
		   //log.info("panCard Matches"+panCard);
		    return true;
		   }
		   else
		   {
		    //log.info("pancard is not matching");
		    return false;
		   }
		
	}
	@Override
	public boolean validateaccountType(String accountType) {
		
		   if(accountType.equals("savingsaccount")) {
		    accountType="savingsaccount";
		    return true;}
		    else if(accountType.equals("currentaccount")){
		     accountType="Currentaccount";
		     return true;}
		    else {
		     System.out.println("please enter correct details");
		   }
		   return false;
		  }

		
	}
	


