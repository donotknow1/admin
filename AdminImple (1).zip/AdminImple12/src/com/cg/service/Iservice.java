package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bean;
import com.cg.bean.Tran;

public interface Iservice {

	int addinfo(Bean b);

	boolean validatename(String name);

	boolean validatemobileNo(String mobileNo);

	boolean validateeMail(String eMail);

	boolean validateopeningBalance(int openingBalance);

	boolean validatepanCard(String panCard);

	boolean validateaccountType(String accountType);

List<Tran> getMonthlyTransactions(int month) throws SQLException;

List<Tran> getYearlyTransactions(int year) throws SQLException;

List<Tran> getDayTransactions(int day) throws SQLException;

List<Tran> retrieveAllTranInfo() throws SQLException;

}
