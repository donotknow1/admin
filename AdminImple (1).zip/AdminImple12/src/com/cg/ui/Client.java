package com.cg.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.bean.Bean;
import com.cg.bean.Tran;
import com.cg.service.Iservice;
import com.cg.service.Serviceimpl;



public class Client {
	static Scanner sc=null;
	static Iservice ser=null;
	public static void main(String[] args) throws SQLException {
		ser=new Serviceimpl();
		sc=new Scanner(System.in);
		System.out.println("1.customer");
		System.out.println("2.admin");
		int choice=sc.nextInt();
		switch (choice) {
		case 1:
			//customer
			break;
		case 2:
			//admin
			
			//int count=0;
			//do {
			System.out.println("ENTER YOUR USERID");
			int adminuserid=sc.nextInt();
			
			
			System.out.println("ENTER YOUR PASSWORD");
			String adminpassword=sc.next();
			
			
			if((adminuserid==1234) && (adminpassword.equals("admin"))) {
			
			administrationLogin();
			//count=3;
			}
			else {
				System.out.println("ENTER VALID LOGIN DETAILS");
				//count++;
			}
			//}while(count<3);
		default:
			break;
		}			
	}
	private static void administrationLogin() throws SQLException {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  CREATE NEW ACCOUNT");
		System.out.println("2  --->  VIEW TRANSACTION");
		int adminoption=sc.nextInt();
		boolean result=true;
		
		String mobileNo;
		String eMail;
		int openingBalance;
		String panCard;
		String accountType;
		
		switch (adminoption) {
		case 1:				
			System.out.println("PLEASE ENTER  DETAILS");
			String name;
			do {
			System.out.println("ENTER YOUR NAME ");
		     name=sc.next();
			ser.validatename(name);
			}while(result==false);	
			
			
			System.out.println("ENTER ADDRESS DETAILS");
			String addressDetails=sc.next();
		
			do {
			System.out.println("ENTER MOBILE NUMBER");
			mobileNo=sc.next();
			ser.validatemobileNo(mobileNo);
			}while(result==false);
			
		do {
			System.out.println("ENTER EMAIL ID");
			 eMail=sc.next();
			ser.validateeMail(eMail);
		}while(result==false);
			
		do {
			System.out.println("OPENING BALANCE");
		 openingBalance=sc.nextInt();
			ser.validateopeningBalance(openingBalance);
		}while(result==false);
		
		do {
			System.out.println("ENTER pan card");
			 panCard=sc.next();
			ser.validatepanCard(panCard);
		}while(result==false);
			
		do {
			System.out.println("enter account type");
			 accountType=sc.next();
			ser.validateaccountType(accountType);
		}while(result==false);
			
			
		Bean b=new Bean(name, addressDetails, mobileNo, eMail, openingBalance, panCard, accountType);
		
	int result1=addinfo(b);				
			
			System.out.println("WELCOME TO CAPGEMINI BANK");
			
			break;
        
        case 2:
        	System.out.println("enter value to see the transaction details ");
        	System.out.println(" PRESS 1  --->  FOR 1 DAY ");
        	System.out.println(" PRESS 2  --->  FOR 1 MONTH ");
        	System.out.println(" PRESS 3  --->  FOR 1 YEAR ");
        	System.out.println(" PRESS 4  --->  ALL TRANSACTION");
        	int choice1=sc.nextInt();
        	switch (choice1) {
        	case 1:
        		System.out.println("enterr the day to get tran");
			       int day=sc.nextInt();
			       List<Tran> finList2= new ArrayList<>();
					
					finList2 = getDayTransactions(day);
					for (Tran tran : finList2) {
						System.out.println(tran);
					}

                 
        	case 2:
				 System.out.println("enterr the month to get tran");
			       int month=sc.nextInt();
			       List<Tran> finList= new ArrayList<>();
				
						finList = getMonthlyTransactions(month);
						for (Tran tran : finList) {
							System.out.println(tran);
						}
						
				break;
			case 3:
				System.out.println("enterr the year to get tran");
			       int year=sc.nextInt();
			       List<Tran> finList3= new ArrayList<>();
					
					finList3 = getYearlyTransactions(year);
					for (Tran tran : finList3) {
						System.out.println(tran);
					}
			       
               break;
			case 4:
				List<Tran> finList1=null;
				
					finList1 = retrieveAllTranInfo();			
			
				for(Tran tran:finList1)
				{
				System.out.println(tran);	
				}
			     
            break;
			default:
				break;
			}   	
				
		}
		
		
	}
	private static List<Tran> getYearlyTransactions(int year) throws SQLException {
		ser=new Serviceimpl();
		return ser.getYearlyTransactions(year);
	}
	private static List<Tran> getDayTransactions(int day) throws SQLException {
		ser=new Serviceimpl();
		return ser.getDayTransactions(day);
		
	}
	private static List<Tran> getMonthlyTransactions(int month) throws SQLException {
		ser=new Serviceimpl();
		return ser.getMonthlyTransactions(month);
	}
	private static List<Tran> retrieveAllTranInfo() throws SQLException {
		ser=new Serviceimpl();
		return ser.retrieveAllTranInfo() ;
	}
	private static int addinfo(Bean b) {
		ser=new Serviceimpl();
		return ser.addinfo(b);
	}
}
	
	

	