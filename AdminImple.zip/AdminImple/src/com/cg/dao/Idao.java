package com.cg.dao;

import com.cg.bean.Bean;

public interface Idao {

	int addinfo(Bean b);

}
