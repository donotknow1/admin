package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	private static Connection conn=null;
	public static Connection getdbconnection()
	{
		String url = "jdbc:oracle:thin:@10.219.34.3:1521/orcl";
		String un = "trg223";
		String pass = "training223";

		try {
			conn=DriverManager.getConnection(url, un, pass);
		} catch (SQLException e) {
			
			System.out.println("not connected"+e.getMessage());
		}
		return conn;
		
	}


}
