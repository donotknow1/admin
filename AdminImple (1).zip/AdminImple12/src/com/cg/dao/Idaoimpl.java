package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bean;
import com.cg.bean.Tran;
import com.cg.util.DbUtil;


public class Idaoimpl implements Idao {
static Connection conn=null;
static int status=0;
	@Override
	public int addinfo(Bean b) {
		conn=DbUtil.getdbconnection();
		try
		{
		PreparedStatement pst=conn.prepareStatement(IQuery.insert_qry);
		pst.setString(1,b.getName());
		pst.setString(2, b.getAddressDetails());
		pst.setString(3, b.getMobileNo());
		pst.setString(4, b.geteMail());
		pst.setInt(5, b.getOpeningBalance());        	
        pst.setString(6, b.getAccountType());
        pst.setString(7, b.getPanCard());
	 status = pst.executeUpdate();
		} catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}	
		return status;
	}
	@Override
	public List<Tran> getMonthlyTransactions(int month) throws SQLException {
		Tran t=null;
		conn=DbUtil.getdbconnection();
		List<Tran> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQuery.retrieve_month);
	    pst1.setInt(1,month);		
	    ResultSet rs=pst1.executeQuery();
	    
	    while(rs.next())
	    	
	    {
	    	//System.out.println("in month");
	    	t=new Tran(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	}
	
	@Override
	public List<Tran> getYearlyTransactions(int year) throws SQLException {
		Tran t=null;
		conn=DbUtil.getdbconnection();
		List<Tran> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQuery.retrieve_year);
	    pst1.setInt(1,year);		
	    ResultSet rs=pst1.executeQuery();
	    
	    while(rs.next())
	    	
	    {
	    	//System.out.println("in month");
	    	t=new Tran(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	
	}
	@Override
	public List<Tran> getDayTransactions(int day) throws SQLException {
		Tran t=null;
		conn=DbUtil.getdbconnection();
		List<Tran> mon=new ArrayList<>();
	    PreparedStatement pst1=conn.prepareStatement(IQuery.retrieve_day);
	    pst1.setInt(1,day);		
	    ResultSet rs=pst1.executeQuery();
	    
	    while(rs.next())
	    	
	    	
	    {
	    	//System.out.println("in month");
	    	t=new Tran(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	
	}
	@Override
	public List<Tran> retrieveAllTranInfo() throws SQLException {
		
		Tran t=null;
		conn=DbUtil.getdbconnection();
		List<Tran> mon=new ArrayList<>();
	    PreparedStatement pst3=conn.prepareStatement(IQuery.retrieveall);
	  		
	    ResultSet rs=pst3.executeQuery();
	    
	    while(rs.next())
	    	
	    	
	    {
	    	//System.out.println("in month");
	    	t=new Tran(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5),rs.getLong(6)); 
	    	 mon.add(t);
	    }   
	    return mon;
	}

}
