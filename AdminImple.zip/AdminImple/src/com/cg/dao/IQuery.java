package com.cg.dao;

public interface IQuery {

	String insert_qry = "insert into customer values(?,?,?,?,?,?,seq.nextval,?)";

}
