package com.cg.service;

import com.cg.bean.Bean;

public interface Iservice {

	int addinfo(Bean b);

	boolean validatename(String name);

	boolean validatemobileNo(String mobileNo);

	boolean validateeMail(String eMail);

	boolean validateopeningBalance(int openingBalance);

	boolean validatepanCard(String panCard);

	boolean validateaccountType(String accountType);

}
