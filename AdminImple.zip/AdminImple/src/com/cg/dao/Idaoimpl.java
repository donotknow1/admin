package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.Bean;
import com.cg.util.DbUtil;


public class Idaoimpl implements Idao {
static Connection conn=null;
static int status=0;
	@Override
	public int addinfo(Bean b) {
		conn=DbUtil.getdbconnection();
		try
		{
		PreparedStatement pst=conn.prepareStatement(IQuery.insert_qry);
		pst.setString(1,b.getName());
		pst.setString(2, b.getAddressDetails());
		pst.setString(3, b.getMobileNo());
		pst.setString(4, b.geteMail());
		pst.setInt(5, b.getOpeningBalance());        	
        pst.setString(6, b.getAccountType());
        pst.setString(7, b.getPanCard());
	 status = pst.executeUpdate();
		} catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}	
		return status;
	}

}
