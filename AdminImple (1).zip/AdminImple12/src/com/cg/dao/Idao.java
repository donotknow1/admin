package com.cg.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bean;
import com.cg.bean.Tran;

public interface Idao {

	int addinfo(Bean b);

	List<Tran> getMonthlyTransactions(int month) throws SQLException;
	List<Tran> getYearlyTransactions(int year) throws SQLException;

	List<Tran> getDayTransactions(int day) throws SQLException;

	List<Tran> retrieveAllTranInfo() throws SQLException;

}
